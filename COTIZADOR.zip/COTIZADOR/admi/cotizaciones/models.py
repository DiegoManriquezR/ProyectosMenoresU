from decimal import Decimal

from django.conf import settings
from django.db import models

from clientes.models import Cliente
from productos.models import Producto
from core.models import Empresa


class Cotizacion(models.Model):
    FORMATO_CHOICES = [
        ("template1", "Formato 1"),
        ("template2", "Formato 2"),
        ("template3", "Formato 3"),
        ("template4", "Formato 4"),
    ]

    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    empresa = models.ForeignKey(Empresa, on_delete=models.SET_NULL, null=True, blank=True)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, null=True, blank=True)
    fecha = models.DateTimeField(auto_now_add=True)
    formato = models.CharField(max_length=20, choices=FORMATO_CHOICES, default="template1")
    descuento_porcentaje = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    descuento_monto = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    total = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    email_envio = models.EmailField(blank=True, null=True)
    notas = models.TextField(blank=True)
    enviado = models.BooleanField(default=False)
    fecha_envio = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-fecha"]

    def __str__(self):
        cliente = getattr(self, "cliente", None)
        cliente_str = cliente if cliente else "Sin cliente"
        return f'Cotización #{self.id or "N/A"} - {cliente_str}'

    def calcular_totales(self):
        items = list(self.items.all())
        subtotal_neto = sum(item.subtotal_neto() for item in items)
        impuestos = sum(item.impuesto_total() for item in items)

        descuento_total = Decimal("0.00")
        if self.descuento_porcentaje > 0:
            descuento_total = subtotal_neto * (self.descuento_porcentaje / Decimal("100"))
        elif self.descuento_monto > 0:
            descuento_total = min(self.descuento_monto, subtotal_neto)

        subtotal_con_descuento = subtotal_neto - descuento_total
        self.subtotal = subtotal_con_descuento
        self.total = subtotal_con_descuento + impuestos
        self.save(update_fields=["subtotal", "total"])
        return self.total

    @property
    def subtotal_bruto(self) -> Decimal:
        return sum(item.subtotal_neto() for item in self.items.all())

    @property
    def descuento_total(self) -> Decimal:
        subtotal = self.subtotal_bruto
        if self.descuento_porcentaje and self.descuento_porcentaje > 0:
            return subtotal * (self.descuento_porcentaje / Decimal("100"))
        if self.descuento_monto and self.descuento_monto > 0:
            return min(self.descuento_monto, subtotal)
        return Decimal("0.00")

    @property
    def impuesto_total(self) -> Decimal:
        return sum(item.impuesto_total() for item in self.items.all())


class CotizacionItem(models.Model):
    cotizacion = models.ForeignKey(Cotizacion, related_name="items", on_delete=models.CASCADE)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    descuento_pct = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    impuesto_pct = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    descripcion = models.CharField(max_length=255, blank=True)

    def subtotal_neto(self) -> Decimal:
        base = Decimal(self.cantidad) * self.precio_unitario
        return base - (base * (self.descuento_pct / Decimal("100")))

    def impuesto_total(self) -> Decimal:
        return self.subtotal_neto() * (self.impuesto_pct / Decimal("100"))

    def subtotal(self) -> Decimal:
        return self.subtotal_neto() + self.impuesto_total()

    def __str__(self):
        return f"{self.producto.nombre} x {self.cantidad}"
