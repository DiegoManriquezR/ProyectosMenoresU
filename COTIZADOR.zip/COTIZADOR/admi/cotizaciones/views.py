import io
import os
from decimal import Decimal
from uuid import uuid4

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import EmailMessage
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.template.loader import render_to_string
from django.utils import timezone
from xhtml2pdf import pisa

from clientes.models import Cliente
from core.models import Empresa
from core.utils import ensure_demo_user, get_empresa_activa, build_email_connection
from productos.models import Producto

from .forms import (
    CotizacionDemoForm,
    CotizacionDemoItemFormSet,
    CotizacionForm,
    CotizacionItemFormSet,
)
from .models import Cotizacion, CotizacionItem


def _get_empresa_usuario(user, request=None):
    if request:
        empresa = get_empresa_activa(request)
        if empresa:
            return empresa
    return Empresa.objects.filter(creado_por=user, es_principal=True).first()


def _rut_placeholder():
    while True:
        rut_tmp = f"S/N-{uuid4().hex[:6]}"
        if not Cliente.objects.filter(rut=rut_tmp).exists():
            return rut_tmp


def _render_cotizacion_html(cotizacion, formato, empresa=None):
    empresa_obj = empresa or cotizacion.empresa or _get_empresa_usuario(cotizacion.creado_por)
    items = list(cotizacion.items.select_related("producto"))
    subtotal_bruto = sum(item.subtotal_neto() for item in items)
    descuento_total = Decimal("0.00")
    if cotizacion.descuento_porcentaje and cotizacion.descuento_porcentaje > 0:
        descuento_total = subtotal_bruto * (cotizacion.descuento_porcentaje / Decimal("100"))
    elif cotizacion.descuento_monto and cotizacion.descuento_monto > 0:
        descuento_total = min(cotizacion.descuento_monto, subtotal_bruto)
    impuestos = sum(item.impuesto_total() for item in items)
    subtotal_con_descuento = subtotal_bruto - descuento_total
    total = subtotal_con_descuento + impuestos

    context = {
        "cotizacion": cotizacion,
        "items": items,
        "empresa": empresa_obj,
        "subtotal_bruto": subtotal_bruto,
        "descuento_total": descuento_total,
        "subtotal_con_descuento": subtotal_con_descuento,
        "impuesto_total": impuestos,
        "total_general": total,
    }
    template_path = f"cotizaciones/formatos/{formato}.html"
    return render_to_string(template_path, context)


def _generar_pdf(request, cotizacion, formato=None):
    selected_format = formato or cotizacion.formato or "template1"
    html_string = _render_cotizacion_html(cotizacion, selected_format)
    result = io.BytesIO()

    def link_callback(uri, rel):
        if uri.startswith(settings.MEDIA_URL):
            path = os.path.join(settings.MEDIA_ROOT, uri.replace(settings.MEDIA_URL, ""))
            return path
        if uri.startswith(settings.STATIC_URL):
            return os.path.join(settings.BASE_DIR, uri.replace(settings.STATIC_URL, "static/"))
        return uri

    pisa.CreatePDF(html_string, dest=result, encoding="utf-8", link_callback=link_callback)
    return result.getvalue()


@login_required
def cotizacion_list(request):
    cotizaciones = (
        Cotizacion.objects.filter(creado_por=request.user)
        .select_related("cliente", "empresa")
        .order_by("-fecha")
    )
    empresa_activa = get_empresa_activa(request)
    if empresa_activa:
        cotizaciones = cotizaciones.filter(empresa=empresa_activa)
    return render(
        request,
        "cotizaciones/cotizacion_list.html",
        {"cotizaciones": cotizaciones, "titulo": "Cotizaciones", "empresa_activa": empresa_activa},
    )


@login_required
def cotizacion_detail(request, pk):
    cotizacion = get_object_or_404(
        Cotizacion.objects.select_related("cliente", "empresa").prefetch_related("items__producto"),
        pk=pk,
        creado_por=request.user,
    )
    empresa = cotizacion.empresa or _get_empresa_usuario(request.user, request)
    subtotal_bruto = cotizacion.subtotal_bruto
    descuento_total = cotizacion.descuento_total
    impuesto_total = cotizacion.impuesto_total
    return render(
        request,
        "cotizaciones/cotizacion_detail.html",
        {
            "cotizacion": cotizacion,
            "items": cotizacion.items.all(),
            "empresa": empresa,
            "titulo": f"Cotización #{cotizacion.id}",
            "subtotal_bruto": subtotal_bruto,
            "descuento_total": descuento_total,
            "impuesto_total": impuesto_total,
        },
    )


@login_required
def cotizacion_create(request):
    ItemFormSet = CotizacionItemFormSet
    empresa_activa = get_empresa_activa(request)
    if request.method == "POST":
        form = CotizacionForm(request.POST, user=request.user)
        formset = ItemFormSet(request.POST, form_kwargs={"user": request.user})
        if form.is_valid() and formset.is_valid():
            cotizacion = form.save(commit=False)
            cotizacion.creado_por = request.user
            cotizacion.empresa = form.cleaned_data.get("empresa") or empresa_activa or _get_empresa_usuario(
                request.user, request
            )
            cliente_libre = form.cleaned_data.get("cliente_libre")
            cliente_libre_email = form.cleaned_data.get("cliente_libre_email")
            if not cotizacion.cliente and cliente_libre:
                cotizacion.cliente = Cliente.objects.create(
                    nombre=cliente_libre,
                    rut=_rut_placeholder(),
                    email=cliente_libre_email or None,
                    creado_por=request.user,
                )
            if not cotizacion.email_envio:
                cotizacion.email_envio = cliente_libre_email or getattr(cotizacion.cliente, "email", None)
            cotizacion.save()

            items = formset.save(commit=False)
            for item in items:
                if item.producto:
                    if not item.precio_unitario:
                        item.precio_unitario = item.producto.precio
                    if item.descuento_pct is None or item.descuento_pct == 0:
                        item.descuento_pct = item.producto.descuento_porcentaje
                    if item.impuesto_pct is None or item.impuesto_pct == 0:
                        item.impuesto_pct = item.producto.impuesto_porcentaje
                    if not item.descripcion:
                        item.descripcion = item.producto.descripcion
                item.cotizacion = cotizacion
                item.save()
            cotizacion.calcular_totales()

            if "guardar_enviar" in request.POST:
                _enviar_cotizacion_email(request, cotizacion)
                messages.success(request, "Cotización creada y enviada correctamente.")
            else:
                messages.success(request, "Cotización creada correctamente.")
            return redirect("cotizaciones:cotizacion_detail", pk=cotizacion.pk)
        messages.error(request, "Corrige los errores del formulario.")
    else:
        form = CotizacionForm(user=request.user, initial={"empresa": empresa_activa})
        formset = ItemFormSet(form_kwargs={"user": request.user})

    return render(
        request,
        "cotizaciones/cotizacion_create.html",
        {
            "form": form,
            "formset": formset,
            "titulo": "Crear Cotización",
        },
    )


@login_required
def cotizacion_update(request, pk):
    cotizacion = get_object_or_404(Cotizacion, pk=pk, creado_por=request.user)
    ItemFormSet = CotizacionItemFormSet
    if request.method == "POST":
        form = CotizacionForm(request.POST, instance=cotizacion, user=request.user)
        formset = ItemFormSet(request.POST, instance=cotizacion, form_kwargs={"user": request.user})
        if form.is_valid() and formset.is_valid():
            cotizacion = form.save(commit=False)
            cliente_libre = form.cleaned_data.get("cliente_libre")
            cliente_libre_email = form.cleaned_data.get("cliente_libre_email")
            if cliente_libre and not cotizacion.cliente:
                cotizacion.cliente = Cliente.objects.create(
                    nombre=cliente_libre,
                    rut=_rut_placeholder(),
                    email=cliente_libre_email or None,
                    creado_por=request.user,
                )
            if not cotizacion.email_envio:
                cotizacion.email_envio = cliente_libre_email or getattr(cotizacion.cliente, "email", None)
            empresa_form = form.cleaned_data.get("empresa")
            if empresa_form:
                cotizacion.empresa = empresa_form
            elif not cotizacion.empresa:
                cotizacion.empresa = _get_empresa_usuario(request.user, request)
            cotizacion.save()
            items = formset.save(commit=False)
            for item in items:
                if item.producto:
                    if not item.descripcion:
                        item.descripcion = item.producto.descripcion
                    if not item.precio_unitario:
                        item.precio_unitario = item.producto.precio
                    if not item.descuento_pct:
                        item.descuento_pct = item.producto.descuento_porcentaje
                    if not item.impuesto_pct:
                        item.impuesto_pct = item.producto.impuesto_porcentaje
                item.save()
            for deleted in formset.deleted_objects:
                deleted.delete()
            cotizacion.calcular_totales()
            messages.success(request, "Cotización actualizada correctamente.")
            return redirect("cotizaciones:cotizacion_detail", pk=cotizacion.pk)
        messages.error(request, "Corrige los errores del formulario.")
    else:
        form = CotizacionForm(instance=cotizacion, user=request.user)
        formset = ItemFormSet(instance=cotizacion, form_kwargs={"user": request.user})

    return render(
        request,
        "cotizaciones/cotizacion_update.html",
        {
            "form": form,
            "formset": formset,
            "cotizacion": cotizacion,
            "titulo": f"Editar Cotización #{cotizacion.id}",
        },
    )


@login_required
def cotizacion_delete(request, pk):
    cotizacion = get_object_or_404(Cotizacion, pk=pk, creado_por=request.user)
    if request.method == "POST":
        cotizacion.delete()
        messages.success(request, "Cotización eliminada correctamente.")
        return redirect("cotizaciones:cotizacion_list")
    context = {"cotizacion": cotizacion, "titulo": "Eliminar Cotización"}
    return render(request, "cotizaciones/cotizacion_confirm_delete.html", context)


@login_required
def cotizacion_enviar(request, pk):
    cotizacion = get_object_or_404(Cotizacion, pk=pk, creado_por=request.user)
    _enviar_cotizacion_email(request, cotizacion)
    messages.success(request, f"Cotización #{cotizacion.id} enviada por email.")
    return redirect("cotizaciones:cotizacion_detail", pk=cotizacion.pk)


@login_required
def cotizacion_pdf(request, pk, formato=None):
    cotizacion = get_object_or_404(
        Cotizacion.objects.select_related("cliente", "empresa").prefetch_related("items__producto"),
        pk=pk,
        creado_por=request.user,
    )
    pdf = _generar_pdf(request, cotizacion, formato)
    response = HttpResponse(pdf, content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="cotizacion-{cotizacion.id}.pdf"'
    return response


def cotizacion_demo(request):
    DemoItemFormSet = CotizacionDemoItemFormSet
    if request.method == "POST":
        form = CotizacionDemoForm(request.POST)
        formset = DemoItemFormSet(request.POST, prefix="items")
        if form.is_valid() and formset.is_valid():
            demo_user = ensure_demo_user()
            empresa = Empresa.objects.create(
                nombre=form.cleaned_data["empresa_nombre"],
                rut=form.cleaned_data.get("empresa_rut"),
                direccion=form.cleaned_data.get("empresa_direccion"),
                email=form.cleaned_data.get("empresa_email"),
                creado_por=demo_user,
                es_principal=True,
            )
            cliente = Cliente.objects.create(
                nombre=form.cleaned_data["cliente_nombre"],
                rut=_rut_placeholder(),
                email=form.cleaned_data.get("cliente_email") or None,
                creado_por=demo_user,
            )
            cotizacion = Cotizacion.objects.create(
                creado_por=demo_user,
                empresa=empresa,
                cliente=cliente,
                formato=form.cleaned_data.get("formato") or "template1",
                descuento_porcentaje=form.cleaned_data.get("descuento_porcentaje") or 0,
                descuento_monto=form.cleaned_data.get("descuento_monto") or 0,
                email_envio=form.cleaned_data.get("cliente_email"),
                notas=form.cleaned_data.get("notas") or "",
            )
            for item_form in formset:
                if not item_form.cleaned_data:
                    continue
                producto = Producto.objects.create(
                    nombre=item_form.cleaned_data["descripcion"],
                    descripcion=item_form.cleaned_data["descripcion"],
                    precio=item_form.cleaned_data["precio_unitario"],
                    descuento_porcentaje=item_form.cleaned_data.get("descuento_pct") or 0,
                    impuesto=None,
                    categoria=None,
                    creado_por=demo_user,
                )
                CotizacionItem.objects.create(
                    cotizacion=cotizacion,
                    producto=producto,
                    descripcion=item_form.cleaned_data["descripcion"],
                    cantidad=item_form.cleaned_data["cantidad"],
                    precio_unitario=item_form.cleaned_data["precio_unitario"],
                    descuento_pct=item_form.cleaned_data.get("descuento_pct") or 0,
                    impuesto_pct=item_form.cleaned_data.get("impuesto_pct") or 0,
                )
            cotizacion.calcular_totales()
            if form.cleaned_data.get("cliente_email"):
                _enviar_cotizacion_email(request, cotizacion, destino=form.cleaned_data.get("cliente_email"))
            messages.success(request, "Demo generada. Descarga tu PDF abajo.")
            return redirect("cotizaciones:cotizacion_demo_result", pk=cotizacion.pk)
        messages.error(request, "Revisa los datos del demo.")
    else:
        form = CotizacionDemoForm()
        formset = DemoItemFormSet(prefix="items")

    return render(
        request,
        "cotizaciones/cotizacion_demo.html",
        {
            "form": form,
            "formset": formset,
        },
    )


def cotizacion_demo_result(request, pk):
    cotizacion = get_object_or_404(
        Cotizacion.objects.select_related("cliente", "empresa").prefetch_related("items__producto"),
        pk=pk,
        creado_por__username="demo_user",
    )
    empresa = cotizacion.empresa
    return render(
        request,
        "cotizaciones/cotizacion_demo_result.html",
        {
            "cotizacion": cotizacion,
            "items": cotizacion.items.all(),
            "empresa": empresa,
            "subtotal_bruto": cotizacion.subtotal_bruto,
            "descuento_total": cotizacion.descuento_total,
            "impuesto_total": cotizacion.impuesto_total,
        },
    )


def cotizacion_demo_pdf(request, pk, formato=None):
    cotizacion = get_object_or_404(Cotizacion, pk=pk, creado_por__username="demo_user")
    pdf = _generar_pdf(request, cotizacion, formato)
    response = HttpResponse(pdf, content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="cotizacion-demo-{cotizacion.id}.pdf"'
    return response


def _enviar_cotizacion_email(request, cotizacion, destino=None):
    cliente = getattr(cotizacion, "cliente", None)
    destino_final = destino or cotizacion.email_envio or (cliente.email if cliente else None)
    if not destino_final:
        messages.error(request, "El cliente no tiene email registrado.")
        return False

    pdf = _generar_pdf(request, cotizacion)
    asunto = f'Cotización #{cotizacion.id}'
    cuerpo = render_to_string(
        "cotizaciones/email_resumen.txt",
        {
            "cotizacion": cotizacion,
            "cliente": cliente,
            "empresa": cotizacion.empresa or _get_empresa_usuario(cotizacion.creado_por, request),
        },
    )

    connection, from_email = build_email_connection(cotizacion.creado_por)
    email = EmailMessage(
        asunto,
        cuerpo,
        from_email or settings.DEFAULT_FROM_EMAIL,
        [destino_final],
        connection=connection,
    )
    email.attach(f"cotizacion-{cotizacion.id}.pdf", pdf, "application/pdf")
    try:
        email.send(fail_silently=False)
    except Exception as exc:
        messages.error(request, f"No se pudo enviar el email: {exc}")
        return False

    if hasattr(cotizacion, "enviado") and hasattr(cotizacion, "fecha_envio"):
        cotizacion.enviado = True
        cotizacion.fecha_envio = timezone.now()
        cotizacion.save(update_fields=["enviado", "fecha_envio"])

    backend_effective = connection.__class__.__module__ if connection else settings.EMAIL_BACKEND
    if "console" in backend_effective:
        messages.warning(
            request,
            "El backend de correo está en modo consola. Configura EMAIL_HOST y credenciales para envío real.",
        )
    return True
