from django.urls import path
from . import views

app_name = 'cotizaciones'

urlpatterns = [
    path('', views.cotizacion_list, name='cotizacion_list'),
    path('crear/', views.cotizacion_create, name='cotizacion_create'),
    path('<int:pk>/', views.cotizacion_detail, name='cotizacion_detail'),
    path('<int:pk>/editar/', views.cotizacion_update, name='cotizacion_update'),
    path('<int:pk>/eliminar/', views.cotizacion_delete, name='cotizacion_delete'),
    path('<int:pk>/enviar/', views.cotizacion_enviar, name='cotizacion_enviar'),
    path('<int:pk>/pdf/', views.cotizacion_pdf, name='cotizacion_pdf'),
    path('<int:pk>/pdf/<str:formato>/', views.cotizacion_pdf, name='cotizacion_pdf_formato'),
    path('demo/', views.cotizacion_demo, name='cotizacion_demo'),
    path('demo/<int:pk>/', views.cotizacion_demo_result, name='cotizacion_demo_result'),
    path('demo/<int:pk>/pdf/', views.cotizacion_demo_pdf, name='cotizacion_demo_pdf'),
    path('demo/<int:pk>/pdf/<str:formato>/', views.cotizacion_demo_pdf, name='cotizacion_demo_pdf_formato'),
]
