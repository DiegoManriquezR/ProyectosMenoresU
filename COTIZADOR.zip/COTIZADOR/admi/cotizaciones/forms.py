import json
from decimal import Decimal

from django import forms
from django.forms import formset_factory, inlineformset_factory
from django.db.models import Q

from core.models import Empresa
from productos.models import Producto

from .models import Cotizacion, CotizacionItem


class CotizacionForm(forms.ModelForm):
    cliente_libre = forms.CharField(
        required=False,
        label="Cliente libre",
        help_text="Si no existe el cliente, escribe un nombre rápido.",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Nombre rápido de cliente"}),
    )
    cliente_libre_email = forms.EmailField(
        required=False,
        label="Email cliente libre",
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "correo@cliente.cl"}),
    )
    empresa = forms.ModelChoiceField(
        queryset=Empresa.objects.none(),
        required=False,
        label="Empresa emisora",
        widget=forms.Select(attrs={"class": "form-select"}),
    )

    class Meta:
        model = Cotizacion
        fields = [
            "empresa",
            "cliente",
            "formato",
            "descuento_porcentaje",
            "descuento_monto",
            "email_envio",
            "notas",
        ]
        widgets = {
            "cliente": forms.Select(attrs={"class": "form-select"}),
            "formato": forms.Select(attrs={"class": "form-select"}),
            "descuento_porcentaje": forms.NumberInput(
                attrs={"class": "form-control", "step": "0.01", "min": "0", "max": "100"}
            ),
            "descuento_monto": forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "min": "0"}),
            "email_envio": forms.EmailInput(attrs={"class": "form-control", "placeholder": "correo@cliente.cl"}),
            "notas": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }
        labels = {
            "cliente": "Cliente",
            "formato": "Formato de cotización",
            "descuento_porcentaje": "Descuento global (%)",
            "descuento_monto": "Descuento global (monto)",
            "email_envio": "Email de envío",
            "notas": "Notas",
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop("user", None)
        super().__init__(*args, **kwargs)
        self.fields["cliente"].required = False

        if self.user:
            empresas = Empresa.objects.filter(creado_por=self.user).order_by("-es_principal", "nombre")
            self.fields["empresa"].queryset = empresas
            if not self.instance.pk and empresas.exists():
                self.fields["empresa"].initial = empresas.filter(es_principal=True).first() or empresas.first()
        else:
            self.fields["empresa"].widget = forms.HiddenInput()

        if not self.is_bound:
            cliente = getattr(self.instance, "cliente", None)
            if cliente and getattr(cliente, "email", None):
                self.fields["email_envio"].initial = cliente.email
            elif getattr(self.instance, "email_envio", None):
                self.fields["email_envio"].initial = self.instance.email_envio

    def clean(self):
        cleaned = super().clean()
        cliente = cleaned.get("cliente")
        cliente_libre = cleaned.get("cliente_libre")
        if not cliente and not cliente_libre:
            raise forms.ValidationError("Selecciona un cliente o escribe un nombre rápido.")
        if not cleaned.get("email_envio") and cliente and getattr(cliente, "email", None):
            cleaned["email_envio"] = cliente.email
        empresa = cleaned.get("empresa")
        if empresa and self.user and empresa.creado_por_id != self.user.id:
            raise forms.ValidationError("La empresa seleccionada no pertenece a tu usuario.")
        return cleaned


class CotizacionItemForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop("user", None)
        super().__init__(*args, **kwargs)
        # Mostrar todos los productos disponibles; si quieres filtrar por usuario, ajusta aquí.
        productos = Producto.objects.filter(creado_por=self.user).order_by("nombre")
        choices = [(p.pk, p.nombre) for p in productos]
        self.fields["producto"].choices = [("", "Seleccionar...")] + choices
        precio_map = {str(p.pk): str(p.precio) for p in productos}
        descuento_map = {str(p.pk): str(p.descuento_porcentaje) for p in productos}
        impuesto_map = {str(p.pk): str(p.impuesto_porcentaje) for p in productos}
        self.fields["producto"].widget.attrs.update(
            {
                "data-precio-json": json.dumps(precio_map),
                "data-descuento-json": json.dumps(descuento_map),
                "data-impuesto-json": json.dumps(impuesto_map),
            }
        )
        if self.instance and self.instance.pk and self.instance.producto:
            # Precio siempre parte en 0 mientras no haya producto
            self.fields["precio_unitario"].initial = Decimal("0.00")
            self.fields["descuento_pct"].initial = self.instance.producto.descuento_porcentaje
            self.fields["impuesto_pct"].initial = self.instance.producto.impuesto_porcentaje

    class Meta:
        model = CotizacionItem
        fields = ["producto", "descripcion", "cantidad", "precio_unitario", "descuento_pct", "impuesto_pct"]
        widgets = {
            "producto": forms.Select(attrs={"class": "form-select"}),
            "descripcion": forms.TextInput(attrs={"class": "form-control", "placeholder": "Detalle opcional"}),
            "cantidad": forms.NumberInput(attrs={"class": "form-control", "min": 1, "value": 1}),
            "precio_unitario": forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "min": 0}),
            "descuento_pct": forms.NumberInput(
                attrs={"class": "form-control", "step": "0.01", "min": 0, "max": 100}
            ),
            "impuesto_pct": forms.NumberInput(
                attrs={"class": "form-control", "step": "0.01", "min": 0, "max": 100}
            ),
        }
        labels = {
            "producto": "Producto",
            "descripcion": "Descripción",
            "cantidad": "Cantidad",
            "precio_unitario": "Precio unitario",
            "descuento_pct": "Descuento (%)",
            "impuesto_pct": "Impuesto (%)",
        }


CotizacionItemFormSet = inlineformset_factory(
    Cotizacion,
    CotizacionItem,
    form=CotizacionItemForm,
    extra=1,
    can_delete=True,
)


class CotizacionDemoForm(forms.Form):
    empresa_nombre = forms.CharField(
        label="Nombre de tu empresa",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Mi empresa SpA"}),
    )
    empresa_email = forms.EmailField(
        label="Email de empresa",
        required=False,
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "ventas@miempresa.cl"}),
    )
    empresa_rut = forms.CharField(
        label="RUT empresa",
        required=False,
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "11.111.111-1"}),
    )
    empresa_direccion = forms.CharField(
        label="Dirección",
        required=False,
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Dirección comercial"}),
    )
    cliente_nombre = forms.CharField(
        label="Cliente",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Nombre del cliente"}),
    )
    cliente_email = forms.EmailField(
        label="Email del cliente",
        required=False,
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "cliente@correo.cl"}),
    )
    formato = forms.ChoiceField(
        choices=Cotizacion.FORMATO_CHOICES,
        initial="template1",
        widget=forms.Select(attrs={"class": "form-select"}),
        label="Formato PDF",
    )
    descuento_porcentaje = forms.DecimalField(
        label="Descuento global (%)",
        required=False,
        min_value=Decimal("0"),
        max_value=Decimal("100"),
        decimal_places=2,
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
    )
    descuento_monto = forms.DecimalField(
        label="Descuento global (monto)",
        required=False,
        min_value=Decimal("0"),
        decimal_places=2,
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
    )
    notas = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={"class": "form-control", "rows": 3, "placeholder": "Notas visibles en la PDF"}),
        label="Notas",
    )


class CotizacionDemoItemForm(forms.Form):
    descripcion = forms.CharField(
        label="Descripción",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Producto o servicio"}),
    )
    cantidad = forms.IntegerField(
        min_value=1,
        initial=1,
        widget=forms.NumberInput(attrs={"class": "form-control", "min": 1}),
        label="Cantidad",
    )
    precio_unitario = forms.DecimalField(
        min_value=Decimal("0"),
        decimal_places=2,
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
        label="Precio unitario",
    )
    descuento_pct = forms.DecimalField(
        required=False,
        min_value=Decimal("0"),
        max_value=Decimal("100"),
        decimal_places=2,
        initial=Decimal("0"),
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
        label="Descuento (%)",
    )
    impuesto_pct = forms.DecimalField(
        required=False,
        min_value=Decimal("0"),
        max_value=Decimal("100"),
        decimal_places=2,
        initial=Decimal("19.00"),
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
        label="Impuesto (%)",
    )


CotizacionDemoItemFormSet = formset_factory(
    CotizacionDemoItemForm,
    extra=3,
    min_num=1,
    validate_min=True,
)
