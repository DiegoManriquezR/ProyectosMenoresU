from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import models
from django.shortcuts import get_object_or_404, redirect, render

from .forms import ClienteForm
from .models import Cliente


# LISTAR CLIENTES
@login_required
def cliente_list(request):
    clientes = Cliente.objects.filter(
        models.Q(creado_por=request.user) | models.Q(creado_por__isnull=True)
    ).order_by("nombre")
    return render(request, 'clientes/list.html', {'clientes': clientes})


# CREAR CLIENTE
@login_required
def cliente_create(request):
    if request.method == "POST":
        form = ClienteForm(request.POST)
        if form.is_valid():
            cliente = form.save(commit=False)
            cliente.creado_por = request.user
            cliente.save()
            messages.success(request, f'Cliente "{cliente.nombre}" creado correctamente.')
            return redirect('clientes:detail', pk=cliente.pk)
        else:
            messages.error(request, 'Por favor corrige los errores en el formulario.')
    else:
        form = ClienteForm()

    return render(request, 'clientes/form.html', {'form': form})


# DETALLE DE CLIENTE
@login_required
def cliente_detail(request, pk):
    cliente = get_object_or_404(
        Cliente.objects.filter(models.Q(creado_por=request.user) | models.Q(creado_por__isnull=True)),
        pk=pk,
    )
    return render(request, 'clientes/detail.html', {'cliente': cliente})


# EDITAR CLIENTE
@login_required
def cliente_edit(request, pk):
    cliente = get_object_or_404(
        Cliente.objects.filter(models.Q(creado_por=request.user) | models.Q(creado_por__isnull=True)),
        pk=pk,
    )

    if request.method == "POST":
        form = ClienteForm(request.POST, instance=cliente)
        if form.is_valid():
            form.save()
            messages.success(request, f'Cliente "{cliente.nombre}" actualizado correctamente.')
            return redirect('clientes:detail', pk=cliente.pk)
        else:
            messages.error(request, 'Por favor corrige los errores en el formulario.')
    else:
        form = ClienteForm(instance=cliente)

    context = {
        'form': form,
        'cliente': cliente,
        'edit': True
    }
    return render(request, 'clientes/form.html', context)


# ELIMINAR CLIENTE
@login_required
def cliente_delete(request, pk):
    cliente = get_object_or_404(
        Cliente.objects.filter(models.Q(creado_por=request.user) | models.Q(creado_por__isnull=True)),
        pk=pk,
    )

    if request.method == "POST":
        nombre = cliente.nombre
        cliente.delete()
        messages.success(request, f'Cliente "{nombre}" eliminado correctamente.')
        return redirect('clientes:list')

    return render(request, 'clientes/confirm_delete.html', {'cliente': cliente})
