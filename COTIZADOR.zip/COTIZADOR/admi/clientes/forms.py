from django import forms

from .models import Cliente


class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ["nombre", "razon_social", "rut", "email", "telefono", "direccion"]

        widgets = {
            "nombre": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Nombre del cliente",
                }
            ),
            "razon_social": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Razón social o nombre de empresa",
                }
            ),
            "rut": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "12345678-9",
                }
            ),
            "email": forms.EmailInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "cliente@ejemplo.com",
                }
            ),
            "telefono": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "+56 9 1234 5678",
                }
            ),
            "direccion": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 3,
                    "placeholder": "Dirección completa del cliente",
                }
            ),
        }

        labels = {
            "nombre": "Nombre",
            "razon_social": "Razón Social / Empresa",
            "rut": "RUT",
            "email": "Email",
            "telefono": "Teléfono",
            "direccion": "Dirección",
        }
