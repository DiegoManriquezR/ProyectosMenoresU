from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from clientes.models import Cliente
from cotizaciones.models import Cotizacion
from productos.models import Producto

from .forms import EmpresaForm, StaffCreateForm, UsuarioCreateForm, UsuarioProfileForm, EmailConfigForm
from .models import Empresa, EmailConfig
from .roles import assign_role
from .utils import get_empresa_activa, set_empresa_activa


def login_view(request):
    ctx = {}
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            get_empresa_activa(request)  # guarda empresa activa en sesión
            return redirect("core:dashboard")
        ctx["error"] = "Credenciales incorrectas"
    return render(request, "login.html", ctx)


def logout_view(request):
    logout(request)
    return redirect("core:login")


def create_user_view(request):
    if request.method == "POST":
        form = UsuarioCreateForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = True
            user.save()
            Empresa.objects.create(
                nombre=form.cleaned_data["nombre_empresa"],
                creado_por=user,
                es_principal=True,
            )
            messages.success(request, "Usuario creado, ahora puedes iniciar sesión.")
            return redirect("core:login")
    else:
        form = UsuarioCreateForm()
    return render(request, "create_user.html", {"form": form})


@login_required
def home_view(request):
    empresa_activa = get_empresa_activa(request)
    clientes_qs = Cliente.objects.filter(creado_por=request.user)
    productos_qs = Producto.objects.filter(creado_por=request.user)
    cotizaciones_qs = Cotizacion.objects.filter(creado_por=request.user)
    if empresa_activa:
        cotizaciones_qs = cotizaciones_qs.filter(empresa=empresa_activa)

    total_clientes = clientes_qs.count()
    total_productos = productos_qs.count()
    total_cotizaciones = cotizaciones_qs.count()
    cotizaciones_enviadas = cotizaciones_qs.filter(enviado=True).count()

    total_vendido = 0
    for c in cotizaciones_qs:
        total_vendido += c.total or c.calcular_totales()
    ultimas_cotizaciones = cotizaciones_qs.order_by("-fecha")[:5]

    context = {
        "total_clientes": total_clientes,
        "total_productos": total_productos,
        "total_cotizaciones": total_cotizaciones,
        "cotizaciones_enviadas": cotizaciones_enviadas,
        "total_vendido": total_vendido,
        "ultimas_cotizaciones": ultimas_cotizaciones,
        "empresa": empresa_activa,
    }
    return render(request, "dashboard.html", context)


@login_required
def empresa_config(request):
    max_empresas = 3

    # 🔹 EMPRESAS DEL USUARIO
    empresas = Empresa.objects.filter(creado_por=request.user)

    # 🔹 EMPRESA ACTIVA DESDE SESIÓN
    empresa_activa = get_empresa_activa(request)

    empresa = None
    nueva = request.GET.get("nueva")

    # =========================
    # GET
    # =========================
    if request.method == "GET":
        empresa_id = request.GET.get("empresa_id")

        if nueva:
            empresa = None  # 👉 formulario vacío
        elif empresa_id:
            empresa = get_object_or_404(
                Empresa,
                id=empresa_id,
                creado_por=request.user
            )
        else:
            empresa = empresa_activa

        form = EmpresaForm(instance=empresa)

    # =========================
    # POST
    # =========================
    else:
        empresa_id = request.POST.get("empresa_id")

        # ----- EDITAR -----
        if empresa_id:
            empresa = get_object_or_404(
                Empresa,
                id=empresa_id,
                creado_por=request.user
            )
            form = EmpresaForm(
                request.POST,
                request.FILES,
                instance=empresa
            )

        # ----- CREAR -----
        else:
            if empresas.count() >= max_empresas:
                messages.error(
                    request,
                    f"No puedes crear más de {max_empresas} empresas."
                )
                return redirect("core:empresa_config")

            form = EmpresaForm(request.POST, request.FILES)

        if form.is_valid():
            empresa = form.save(commit=False)
            empresa.creado_por = request.user

            # ----- MARCAR PRINCIPAL -----
            if request.POST.get("marcar_principal"):
                Empresa.objects.filter(
                    creado_por=request.user,
                    es_principal=True
                ).update(es_principal=False)
                empresa.es_principal = True

            empresa.save()

            messages.success(request, "Empresa guardada correctamente.")
            return redirect("core:empresa_config")

    context = {
        "form": form,
        "empresas": empresas,
        "empresa": empresa,
        "empresa_activa": empresa_activa,
        "max_empresas": max_empresas,
    }

    return render(request, "core/empresa_form.html", context)



@login_required
def empresa_activar(request, pk):
    empresa = get_object_or_404(Empresa, pk=pk, creado_por=request.user)
    set_empresa_activa(request, empresa)
    messages.success(request, f"{empresa.nombre} ahora es la empresa activa.")
    return redirect(request.GET.get("next") or "core:empresa_config")


@login_required
def perfil_view(request):
    if request.method == "POST":
        form = UsuarioProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Perfil actualizado.")
            return redirect("core:perfil")
        messages.error(request, "Corrige los errores del formulario.")
    else:
        form = UsuarioProfileForm(instance=request.user)
    return render(request, "core/edit_profile.html", {"form": form})


@login_required
def staff_create(request):
    if not request.user.is_superuser:
        messages.error(request, "Solo los administradores pueden crear miembros del staff.")
        return redirect("core:dashboard")

    if request.method == "POST":
        form = StaffCreateForm(request.POST)
        if form.is_valid():
            staff = form.save(commit=False)
            staff.is_active = True
            staff.save()
            assign_role(staff, form.cleaned_data["role"])
            messages.success(
                request,
                f'Usuario "{staff.username}" creado con rol {form.cleaned_data["role"]}.',
            )
            return redirect("core:staff_create")
        messages.error(request, "Revisa los datos ingresados.")
    else:
        form = StaffCreateForm()

    return render(request, "core/staff_form.html", {"form": form})


@login_required
def email_config(request):
    config = EmailConfig.objects.filter(creado_por=request.user).first()
    if request.method == "POST":
        form = EmailConfigForm(request.POST, instance=config)
        if form.is_valid():
            email_conf = form.save(commit=False)
            email_conf.creado_por = request.user
            # Si no escribe contraseña y ya hay una guardada, conservarla
            if not form.cleaned_data.get("password") and config and config.password:
                email_conf.password = config.password
            email_conf.save()
            messages.success(request, "Configuración de correo guardada.")
            return redirect("core:email_config")
        messages.error(request, "Revisa los datos del formulario.")
    else:
        form = EmailConfigForm(instance=config)
    return render(
        request,
        "core/email_config.html",
        {
            "form": form,
            "config": config,
        },
    )
