from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission


ADMIN_APPS = ["clientes", "productos", "cotizaciones", "core"]


ROLE_PERMISSIONS = {
    "Administrador": None,  # se asignan todas las de ADMIN_APPS
    "Supervisor": [
        "view_cliente",
        "add_cliente",
        "change_cliente",
        "view_producto",
        "add_producto",
        "change_producto",
        "view_categoria",
        "add_categoria",
        "change_categoria",
        "view_impuesto",
        "add_impuesto",
        "change_impuesto",
        "view_cotizacion",
        "add_cotizacion",
        "change_cotizacion",
        "delete_cotizacion",
        "view_cotizacionitem",
        "add_cotizacionitem",
        "change_cotizacionitem",
        "delete_cotizacionitem",
        "view_empresa",
        "change_empresa",
    ],
    "Vendedor": [
        "view_cliente",
        "add_cliente",
        "change_cliente",
        "view_producto",
        "view_categoria",
        "view_impuesto",
        "view_cotizacion",
        "add_cotizacion",
        "change_cotizacion",
        "view_cotizacionitem",
        "add_cotizacionitem",
        "change_cotizacionitem",
        "view_empresa",
    ],
}


def ensure_role_groups(sender=None, **kwargs):
    """
    Crea/actualiza grupos de roles con permisos m├¡nimos.
    Se llama en post_migrate y puede usarse en runtime.
    """
    all_permissions = Permission.objects.filter(content_type__app_label__in=ADMIN_APPS)

    # Administrador obtiene todos los permisos de los m├│dulos definidos.
    admin_group, _ = Group.objects.get_or_create(name="Administrador")
    admin_group.permissions.set(all_permissions)

    for role, codename_list in ROLE_PERMISSIONS.items():
        if role == "Administrador":
            continue
        group, _ = Group.objects.get_or_create(name=role)
        perms = Permission.objects.filter(codename__in=codename_list)
        group.permissions.set(perms)


def assign_role(user, role_name):
    """Asigna el grupo de rol indicado y marca al usuario como staff."""
    ensure_role_groups()
    try:
        group = Group.objects.get(name=role_name)
    except Group.DoesNotExist:
        return

    user.groups.clear()
    user.groups.add(group)
    if not user.is_staff:
        user.is_staff = True
        user.save(update_fields=["is_staff"])


def sync_superuser_group(sender, instance, created, **kwargs):
    """
    Cada superusuario se asegura dentro del grupo Administrador para heredar permisos.
    """
    if not instance.is_superuser:
        return

    ensure_role_groups()
    admin_group = Group.objects.filter(name="Administrador").first()
    if admin_group:
        instance.groups.add(admin_group)
    if not instance.is_staff:
        instance.is_staff = True
        instance.save(update_fields=["is_staff"])
