from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "core"

    def ready(self):
        from django.db.models.signals import post_migrate, post_save
        from django.contrib.auth import get_user_model

        from .roles import ensure_role_groups, sync_superuser_group

        post_migrate.connect(ensure_role_groups, sender=self)

        User = get_user_model()
        post_save.connect(sync_superuser_group, sender=User, weak=False)
