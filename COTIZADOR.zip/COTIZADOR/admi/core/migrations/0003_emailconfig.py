from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0002_empresa'),
    ]

    operations = [
        migrations.CreateModel(
            name='EmailConfig',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('host', models.CharField(default='smtp.gmail.com', max_length=255)),
                ('port', models.PositiveIntegerField(default=587)),
                ('username', models.CharField(blank=True, max_length=255, null=True)),
                ('password', models.CharField(blank=True, max_length=255, null=True)),
                ('use_tls', models.BooleanField(default=True)),
                ('use_ssl', models.BooleanField(default=False)),
                ('default_from', models.EmailField(blank=True, max_length=254, null=True)),
                ('backend', models.CharField(default='django.core.mail.backends.smtp.EmailBackend', max_length=255)),
                ('actualizado_en', models.DateTimeField(auto_now=True)),
                ('creado_por', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='email_config', to='core.usuario')),
            ],
            options={
                'verbose_name': 'Configuración de correo',
                'verbose_name_plural': 'Configuraciones de correo',
            },
        ),
    ]
