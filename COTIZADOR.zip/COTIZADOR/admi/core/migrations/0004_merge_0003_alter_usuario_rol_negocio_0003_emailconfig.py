from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0003_alter_usuario_rol_negocio'),
        ('core', '0003_emailconfig'),
    ]

    operations = []
