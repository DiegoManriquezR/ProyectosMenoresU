from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import Empresa, Usuario, RUBRO_CHOICES, EmailConfig


class UsuarioCreateForm(UserCreationForm):
    nombre_empresa = forms.CharField(
        label="Nombre de PYME/EMPRESA",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Nombre de la empresa"}),
        required=True,
    )
    first_name = forms.CharField(
        label="Nombre(s)",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Ingresa tus nombres"}),
        required=True,
    )
    last_name = forms.CharField(
        label="Apellido(s)",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Ingresa tus apellidos"}),
        required=True,
    )
    email = forms.EmailField(
        label="Email",
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "usuario@ejemplo.com"}),
        required=True,
    )
    rol_negocio = forms.ChoiceField(
        label="Rubro de negocio",
        choices=RUBRO_CHOICES,
        widget=forms.Select(attrs={"class": "form-select"}),
        required=True,
    )

    class Meta:
        model = Usuario
        fields = (
            "username",
            "nombre_empresa",
            "first_name",
            "last_name",
            "email",
            "rol_negocio",
            "password1",
            "password2",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].widget.attrs.update(
            {"class": "form-control", "placeholder": "Usuario para login (sin espacios)"}
        )
        self.fields["password1"].widget.attrs.update({"class": "form-control", "placeholder": "Contraseña"})
        self.fields["password2"].widget.attrs.update({"class": "form-control", "placeholder": "Confirmar contraseña"})


class EmpresaForm(forms.ModelForm):
    class Meta:
        model = Empresa
        fields = ["nombre", "rut", "giro", "direccion", "telefono", "email", "sitio_web", "logo"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control", "required": True}),
            "rut": forms.TextInput(attrs={"class": "form-control"}),
            "giro": forms.TextInput(attrs={"class": "form-control"}),
            "direccion": forms.TextInput(attrs={"class": "form-control"}),
            "telefono": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control"}),
            "sitio_web": forms.URLInput(attrs={"class": "form-control"}),
            "logo": forms.ClearableFileInput(attrs={"class": "form-control"}),
        }
        labels = {
            "nombre": "Nombre legal",
            "rut": "RUT",
            "giro": "Giro",
            "direccion": "Dirección",
            "telefono": "Teléfono",
            "email": "Email",
            "sitio_web": "Sitio web",
            "logo": "Logo / imagen",
        }


class UsuarioProfileForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ["first_name", "last_name", "email", "telefono", "rut", "rol_negocio"]
        labels = {
            "first_name": "Nombre",
            "last_name": "Apellido",
            "email": "Email",
            "telefono": "Teléfono",
            "rut": "RUT",
            "rol_negocio": "Rubro",
        }
        widgets = {
            "first_name": forms.TextInput(attrs={"class": "form-control"}),
            "last_name": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control"}),
            "telefono": forms.TextInput(attrs={"class": "form-control"}),
            "rut": forms.TextInput(attrs={"class": "form-control"}),
            "rol_negocio": forms.Select(attrs={"class": "form-select"}),
        }


class StaffCreateForm(UserCreationForm):
    role = forms.ChoiceField(
        choices=[
            ("Administrador", "Administrador"),
            ("Supervisor", "Supervisor"),
            ("Vendedor", "Vendedor"),
        ],
        label="Rol / Permisos",
        widget=forms.Select(attrs={"class": "form-select"}),
    )

    class Meta:
        model = Usuario
        fields = ("username", "first_name", "last_name", "email", "role", "password1", "password2")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name in ["username", "first_name", "last_name", "email", "password1", "password2"]:
            field = self.fields.get(field_name)
            if field:
                field.widget.attrs.update({"class": "form-control"})


class EmailConfigForm(forms.ModelForm):
    password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}),
        label="Contraseña SMTP",
        help_text="Si la dejas vacía, se mantiene la existente.",
    )

    class Meta:
        model = EmailConfig
        fields = ["host", "port", "username", "password", "use_tls", "use_ssl", "default_from", "backend"]
        widgets = {
            "host": forms.TextInput(attrs={"class": "form-control"}),
            "port": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "username": forms.TextInput(attrs={"class": "form-control"}),
            "use_tls": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "use_ssl": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "default_from": forms.EmailInput(attrs={"class": "form-control"}),
            "backend": forms.TextInput(attrs={"class": "form-control"}),
        }
        labels = {
            "host": "Host SMTP",
            "port": "Puerto",
            "username": "Usuario",
            "default_from": "Remitente por defecto (From)",
            "use_tls": "Usar TLS",
            "use_ssl": "Usar SSL",
            "backend": "Backend (normalmente smtp)",
        }
