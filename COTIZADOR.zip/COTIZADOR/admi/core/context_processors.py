from .utils import get_empresa_activa


def empresa_context(request):
    """
    Aporta la empresa activa a todos los templates autenticados.
    No rompe vistas p├║blicas porque simplemente devuelve None.
    """
    return {"empresa_activa": get_empresa_activa(request)}
