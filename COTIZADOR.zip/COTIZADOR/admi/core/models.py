from django.contrib.auth.models import AbstractUser
from django.db import models

# Rubros de negocio para PYMES (global para forms y models)
RUBRO_CHOICES = [
    ("agricultura", "Agricultura"),
    ("ganaderia", "Ganadería"),
    ("pesca", "Pesca"),
    ("comercio", "Comercio"),
    ("restauracion", "Restauración / Gastronomía"),
    ("turismo", "Turismo / Hotelería"),
    ("salud", "Salud / Clínicas / Farmacias"),
    ("educacion", "Educación / Capacitación"),
    ("servicios_profesionales", "Servicios Profesionales"),
    ("tecnologia", "Tecnología / Software / Informática"),
    ("industria", "Industria / Manufactura"),
    ("construccion", "Construcción"),
    ("transporte", "Transporte / Logística"),
    ("marketing", "Marketing / Publicidad / Diseño"),
    ("finanzas", "Finanzas / Seguros / Contabilidad"),
    ("textil", "Textil / Moda / Ropa"),
    ("electronica", "Electrónica / Electrodomésticos"),
    ("farmaceutico", "Farmacéutico / Laboratorio"),
    ("energia", "Energía / Medio ambiente"),
    ("automotriz", "Automotriz"),
    ("alimentos", "Alimentos y Bebidas"),
    ("ferreteria", "Ferretería"),
    ("pasteleria", "Pastelería"),
    ("servicios_generales", "Servicios Generales"),
    ("otro", "Otro"),
]

class Usuario(AbstractUser):
    rut = models.CharField(max_length=20, blank=True, null=True)
    telefono = models.CharField(max_length=30, blank=True, null=True)
    rol_negocio = models.CharField(max_length=50, choices=RUBRO_CHOICES, default="otro")

    class Meta:
        verbose_name = "Usuario"
        verbose_name_plural = "Usuarios"

    def __str__(self):
        return self.username


class Empresa(models.Model):
    nombre = models.CharField(max_length=255)
    rut = models.CharField(max_length=20, blank=True, null=True)
    giro = models.CharField(max_length=255, blank=True, null=True)
    direccion = models.CharField(max_length=255, blank=True, null=True)
    telefono = models.CharField(max_length=30, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    sitio_web = models.URLField(blank=True, null=True)
    logo = models.ImageField(upload_to="logos/", blank=True, null=True)
    creado_por = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="empresas")
    es_principal = models.BooleanField(default=True)
    creado_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Empresa"
        verbose_name_plural = "Empresas"

    def __str__(self):
        return self.nombre


class EmailConfig(models.Model):
    creado_por = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name="email_config")
    host = models.CharField(max_length=255, default="smtp.gmail.com")
    port = models.PositiveIntegerField(default=587)
    username = models.CharField(max_length=255, blank=True, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    use_tls = models.BooleanField(default=True)
    use_ssl = models.BooleanField(default=False)
    default_from = models.EmailField(blank=True, null=True)
    backend = models.CharField(max_length=255, default="django.core.mail.backends.smtp.EmailBackend")
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Configuración de correo"
        verbose_name_plural = "Configuraciones de correo"

    def __str__(self):
        return f"SMTP {self.host}:{self.port}"
