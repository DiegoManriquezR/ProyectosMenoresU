from django.contrib.auth import get_user_model
from django.core.mail import get_connection
from django.conf import settings

from .models import Empresa, EmailConfig

EMPRESA_SESSION_KEY = "empresa_activa_id"


def get_empresa_activa(request):
    """
    Devuelve la empresa activa del usuario guardada en sesion.
    Si no existe, marca como activa la principal o la primera disponible.
    """
    if not getattr(request, "user", None) or not request.user.is_authenticated:
        return None

    empresa_id = request.session.get(EMPRESA_SESSION_KEY)
    if empresa_id:
        empresa = Empresa.objects.filter(pk=empresa_id, creado_por=request.user).first()
        if empresa:
            return empresa

    empresa = (
        Empresa.objects.filter(creado_por=request.user)
        .order_by("-es_principal", "-id")
        .first()
    )
    if empresa:
        request.session[EMPRESA_SESSION_KEY] = empresa.id
    return empresa


def set_empresa_activa(request, empresa: Empresa):
    """Guarda en sesion la empresa activa si pertenece al usuario."""
    if empresa and empresa.creado_por_id == request.user.id:
        request.session[EMPRESA_SESSION_KEY] = empresa.id
        return empresa
    return None


def ensure_demo_user():
    """
    Obtiene o crea un usuario demo sin contrasena util para modo libre.
    No se expone en el login y sirve para asociar datos de pruebas.
    """
    User = get_user_model()
    demo_user, created = User.objects.get_or_create(
        username="demo_user",
        defaults={
            "first_name": "Demo",
            "last_name": "Publico",
            "email": "demo@example.com",
            "is_active": True,
        },
    )
    if created:
        demo_user.set_unusable_password()
        demo_user.save(update_fields=["password"])
    return demo_user


def build_email_connection(user):
    """
    Devuelve (connection, from_email) usando la configuración del usuario si existe.
    Si no hay config, retorna None y se usa la de settings.
    """
    conf = EmailConfig.objects.filter(creado_por=user).first()
    if not conf:
        return None, settings.DEFAULT_FROM_EMAIL

    backend = conf.backend or settings.EMAIL_BACKEND
    from_email = conf.default_from or settings.DEFAULT_FROM_EMAIL
    connection = get_connection(
        backend=backend,
        host=conf.host,
        port=conf.port,
        username=conf.username,
        password=conf.password,
        use_tls=conf.use_tls,
        use_ssl=conf.use_ssl,
    )
    return connection, from_email
