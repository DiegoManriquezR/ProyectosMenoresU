from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.shortcuts import redirect
from django.urls import include, path

def root_redirect(request):
    if request.user.is_authenticated:
        return redirect('core:dashboard')
    return redirect('core:login')

urlpatterns = [
    path('', root_redirect, name='root'),

   
    path('create-user/', include(('core.urls', 'core'), namespace='core_create_user')),

    path('core/', include('core.urls')),
    path('clientes/', include('clientes.urls')),
    path('productos/', include('productos.urls')),
    path('cotizaciones/', include('cotizaciones.urls')),
    
    path('admin/', admin.site.urls),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
