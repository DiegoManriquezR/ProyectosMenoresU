from django.urls import path
from . import views

app_name = 'productos'

urlpatterns = [
    path('', views.producto_list, name='producto_list'),
    path('crear/', views.producto_create, name='producto_create'),
    path('<int:pk>/', views.producto_detail, name='detail'),
    path('<int:pk>/editar/', views.producto_edit, name='edit'),
    path('<int:pk>/eliminar/', views.producto_delete, name='delete'),

    # RUTAS DE CATEGORÍAS (NUEVAS)
    path('categorias/', views.categoria_list, name='categoria_list'),
    path('categorias/crear/', views.categoria_create, name='categoria_create'),
    path('categorias/<int:pk>/editar/', views.categoria_edit, name='categoria_edit'),
    path('categorias/<int:pk>/eliminar/', views.categoria_delete, name='categoria_delete'),

    # IMPUESTOS
    path('impuestos/', views.impuesto_list, name='impuesto_list'),
    path('impuestos/crear/', views.impuesto_create, name='impuesto_create'),
    path('impuestos/<int:pk>/editar/', views.impuesto_edit, name='impuesto_edit'),
    path('impuestos/<int:pk>/eliminar/', views.impuesto_delete, name='impuesto_delete'),
]
