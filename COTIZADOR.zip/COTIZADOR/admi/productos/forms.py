from django import forms

from .models import Categoria, Impuesto, Producto


class ProductoForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["impuesto"].queryset = Impuesto.objects.filter(activo=True).order_by("-tasa")

    class Meta:
        model = Producto
        fields = [
            "codigo",
            "nombre",
            "descripcion",
            "precio",
            "unidad_medida",
            "descuento_porcentaje",
            "impuesto",
            "categoria",
        ]

        widgets = {
            "codigo": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Ej: PRD-0005 (opcional)",
                }
            ),
            "nombre": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Nombre del producto",
                    "required": True,
                }
            ),
            "descripcion": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 3,
                    "placeholder": "Descripción breve del producto",
                }
            ),
            "precio": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "step": "0.01",
                    "min": "0",
                    "placeholder": "0.00",
                }
            ),
            "unidad_medida": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Ej: unidad, kg, litros, m2",
                }
            ),
            "descuento_porcentaje": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "step": "0.01",
                    "min": "0",
                    "max": "100",
                    "placeholder": "0",
                }
            ),
            "impuesto": forms.Select(attrs={"class": "form-select"}),
            "categoria": forms.Select(attrs={"class": "form-select"}),
        }

        labels = {
            "codigo": "Código interno",
            "nombre": "Nombre",
            "descripcion": "Descripción",
            "precio": "Precio",
            "unidad_medida": "Unidad de medida",
            "descuento_porcentaje": "Descuento (%)",
            "impuesto": "Tipo de impuesto",
            "categoria": "Categoría",
        }


class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = ["nombre"]

        widgets = {
            "nombre": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Nombre de la categoría",
                }
            ),
        }

        labels = {
            "nombre": "Nombre",
        }


class ImpuestoForm(forms.ModelForm):
    class Meta:
        model = Impuesto
        fields = ["nombre", "tasa", "activo"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control", "placeholder": "Nombre del impuesto"}),
            "tasa": forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "min": "0"}),
            "activo": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }
        labels = {
            "nombre": "Nombre",
            "tasa": "Tasa (%)",
            "activo": "Activo",
        }
