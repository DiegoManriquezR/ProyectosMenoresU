from decimal import Decimal

from django.conf import settings
from django.db import models


class Categoria(models.Model):
    nombre = models.CharField(max_length=100)
    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre


class Impuesto(models.Model):
    nombre = models.CharField(max_length=100)
    tasa = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    activo = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Impuesto"
        verbose_name_plural = "Impuestos"
        ordering = ["-activo", "nombre"]

    def __str__(self):
        return f"{self.nombre} ({self.tasa}%)"


class Producto(models.Model):
    codigo = models.CharField(
        max_length=30,
        unique=True,
        blank=True,
        null=True,
        help_text="Código interno. Si lo dejas vacío se genera automáticamente.",
    )
    nombre = models.CharField(max_length=200)
    descripcion = models.TextField(blank=True)
    precio = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    unidad_medida = models.CharField(max_length=50, blank=True)
    descuento_porcentaje = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("0.00"),
        help_text="Descuento estándar para el producto (0-100%).",
    )
    impuesto = models.ForeignKey(Impuesto, on_delete=models.SET_NULL, null=True, blank=True)
    categoria = models.ForeignKey(Categoria, on_delete=models.SET_NULL, null=True, blank=True)
    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-fecha_creacion"]

    def __str__(self):
        codigo = f"[{self.codigo}] " if self.codigo else ""
        return f"{codigo}{self.nombre}"

    @property
    def impuesto_porcentaje(self) -> Decimal:
        if self.impuesto:
            return self.impuesto.tasa
        return Decimal("0.00")

    def save(self, *args, **kwargs):
        if not self.codigo:
            last = Producto.objects.order_by("-id").first()
            next_number = (last.id + 1) if last else 1
            self.codigo = f"PRD-{next_number:04d}"
        if not self.impuesto:
            default_imp = Impuesto.objects.filter(activo=True).order_by("-tasa").first()
            if default_imp:
                self.impuesto = default_imp
        super().save(*args, **kwargs)
