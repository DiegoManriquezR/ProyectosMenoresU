from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from .forms import CategoriaForm, ImpuestoForm, ProductoForm
from .models import Categoria, Impuesto, Producto


@login_required
def producto_list(request):
    productos = Producto.objects.select_related("categoria", "impuesto").order_by("-fecha_creacion")
    return render(
        request,
        "productos/list.html",
        {
            "productos": productos,
            "titulo": "Productos",
        },
    )


@login_required
def producto_detail(request, pk):
    producto = get_object_or_404(
        Producto.objects.filter(Q(creado_por=request.user) | Q(creado_por__isnull=True)),
        pk=pk,
    )
    return render(
        request,
        "productos/detail.html",
        {
            "producto": producto,
            "titulo": f"Producto: {producto.nombre}",
        },
    )


@login_required
def producto_create(request):
    if request.method == "POST":
        form = ProductoForm(request.POST)
        if form.is_valid():
            producto = form.save(commit=False)
            producto.creado_por = request.user
            producto.save()
            messages.success(request, f'Producto "{producto.nombre}" creado correctamente.')
            return redirect("productos:producto_list")
        messages.error(request, "Por favor corrige los errores del formulario.")
    else:
        form = ProductoForm()

    return render(
        request,
        "productos/form.html",
        {
            "form": form,
            "titulo": "Crear Producto",
        },
    )


@login_required
def producto_edit(request, pk):
    producto = get_object_or_404(Producto, pk=pk)

    if request.method == "POST":
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, f'Producto "{producto.nombre}" actualizado correctamente.')
            return redirect("productos:detail", pk=producto.pk)
        messages.error(request, "Revisa los datos ingresados.")
    else:
        form = ProductoForm(instance=producto)

    return render(
        request,
        "productos/form.html",
        {
            "form": form,
            "producto": producto,
            "edit": True,
            "titulo": f"Editar Producto: {producto.nombre}",
        },
    )


@login_required
def producto_delete(request, pk):
    producto = get_object_or_404(Producto, pk=pk)

    if request.method == "POST":
        nombre = producto.nombre
        producto.delete()
        messages.success(request, f'Producto "{nombre}" eliminado correctamente.')
        return redirect("productos:producto_list")

    return render(
        request,
        "productos/confirm_delete.html",
        {
            "producto": producto,
            "titulo": "Eliminar Producto",
        },
    )


@login_required
def categoria_list(request):
    categorias = Categoria.objects.filter(Q(creado_por=request.user) | Q(creado_por__isnull=True))
    return render(
        request,
        "productos/categoria_list.html",
        {
            "categorias": categorias,
            "titulo": "Categorías",
        },
    )


@login_required
def categoria_create(request):
    if request.method == "POST":
        form = CategoriaForm(request.POST)
        if form.is_valid():
            categoria = form.save(commit=False)
            categoria.creado_por = request.user
            categoria.save()
            messages.success(request, f'Categoría "{categoria.nombre}" creada correctamente.')
            return redirect("productos:categoria_list")
        messages.error(request, "Revisa los datos ingresados.")
    else:
        form = CategoriaForm()

    return render(
        request,
        "productos/categoria_form.html",
        {
            "form": form,
            "titulo": "Crear Categoría",
        },
    )


@login_required
def categoria_edit(request, pk):
    categoria = get_object_or_404(
        Categoria.objects.filter(Q(creado_por=request.user) | Q(creado_por__isnull=True)),
        pk=pk,
    )

    if request.method == "POST":
        form = CategoriaForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            messages.success(request, "Categoría actualizada.")
            return redirect("productos:categoria_list")
        messages.error(request, "Corrige los errores del formulario.")
    else:
        form = CategoriaForm(instance=categoria)

    return render(
        request,
        "productos/categoria_form.html",
        {
            "form": form,
            "edit": True,
            "titulo": "Editar Categoría",
        },
    )


@login_required
def categoria_delete(request, pk):
    categoria = get_object_or_404(
        Categoria.objects.filter(Q(creado_por=request.user) | Q(creado_por__isnull=True)),
        pk=pk,
    )
    if request.method == "POST":
        categoria.delete()
        messages.success(request, "Categoría eliminada.")
        return redirect("productos:categoria_list")
    return render(
        request,
        "productos/categoria_confirm_delete.html",
        {
            "categoria": categoria,
            "titulo": "Eliminar Categoría",
        },
    )


# -------------------------------------------------------
# IMPUESTOS
# -------------------------------------------------------

@login_required
def impuesto_list(request):
    impuestos = Impuesto.objects.all()
    return render(
        request,
        "productos/impuesto_list.html",
        {"impuestos": impuestos, "titulo": "Impuestos"},
    )


@login_required
def impuesto_create(request):
    if request.method == "POST":
        form = ImpuestoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Impuesto creado.")
            return redirect("productos:impuesto_list")
        messages.error(request, "Revisa los datos.")
    else:
        form = ImpuestoForm()
    return render(request, "productos/impuesto_form.html", {"form": form, "titulo": "Crear impuesto"})


@login_required
def impuesto_edit(request, pk):
    impuesto = get_object_or_404(Impuesto, pk=pk)
    if request.method == "POST":
        form = ImpuestoForm(request.POST, instance=impuesto)
        if form.is_valid():
            form.save()
            messages.success(request, "Impuesto actualizado.")
            return redirect("productos:impuesto_list")
        messages.error(request, "Corrige los errores.")
    else:
        form = ImpuestoForm(instance=impuesto)
    return render(
        request,
        "productos/impuesto_form.html",
        {"form": form, "impuesto": impuesto, "titulo": "Editar impuesto"},
    )


@login_required
def impuesto_delete(request, pk):
    impuesto = get_object_or_404(Impuesto, pk=pk)
    if request.method == "POST":
        impuesto.delete()
        messages.success(request, "Impuesto eliminado.")
        return redirect("productos:impuesto_list")
    return render(
        request,
        "productos/impuesto_confirm_delete.html",
        {"impuesto": impuesto, "titulo": "Eliminar impuesto"},
    )
