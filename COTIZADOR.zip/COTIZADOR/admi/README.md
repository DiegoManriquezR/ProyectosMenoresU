ADMI Prototype (Django) - Option B (Functional prototype)
Includes:
- Django project `admi`
- Apps: `core`, `clientes`, `cotizaciones`
- Auth with custom Usuario model, user creation form via login screen
- CRUD for Clientes and Cotizaciones (minimal functional)
- Simple role assignment using Django Groups (admin can assign)
- SQLite DB by default for quick start (change to MySQL in settings if needed)
- No Bootstrap; simple CSS and centered layout

Quick start:
1. python -m venv venv
2. source venv/bin/activate   # or venv\Scripts\activate on Windows
3. pip install -r requirements.txt
4. python manage.py migrate
5. python manage.py createsuperuser
6. python manage.py runserver
Open http://127.0.0.1:8000/

## Configurar envío de correo (SMTP)

Por defecto el backend de correo es de consola. Para enviar correos reales (p. ej. las cotizaciones):

1. Exporta variables de entorno antes de levantar el servidor (o crea un `.env`):
   ```
   EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
   EMAIL_HOST=smtp.tu-proveedor.com
   EMAIL_PORT=587               # o 465 si usas SSL
   EMAIL_HOST_USER=tu_correo@dominio.com
   EMAIL_HOST_PASSWORD=tu_password_app
   EMAIL_USE_TLS=True           # para 587; si usas 465, usa EMAIL_USE_SSL=True y quita USE_TLS
   DEFAULT_FROM_EMAIL=tu_correo@dominio.com
   ```
2. Reinicia el servidor.
3. Prueba “Guardar y enviar” una cotización. Si la conexión falla verás el mensaje de error en pantalla.
